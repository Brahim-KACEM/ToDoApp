
package com.example.todo.controller;

import org.springframework.web.bind.annotation.*;
import com.example.todo.model.Todo;
import java.util.List;
import java.util.ArrayList;

@RestController
@RequestMapping("/api/todos")
public class TodoController {

   @GetMapping
    public List<Todo> getTodos() {
        // Dummy data with values
        return List.of(
            new Todo(1L, "Learn Spring Boot", "Setup backend for todo app", false),
            new Todo(2L, "Create UI", "Design simple React frontend", true)
        );
    }


    @PostMapping
    public Todo addTodo(@RequestBody Todo todo) {
        // TODO: Implement
        return todo;
    }
}
